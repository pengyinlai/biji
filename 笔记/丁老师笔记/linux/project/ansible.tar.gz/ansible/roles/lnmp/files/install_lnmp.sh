#!/bin/bash
yum -y install gcc openssl-devel pcre-devel make autoconf
useradd -s /sbin/nologin  nginx
cd /tmp/
tar -xf nginx-1.17.6.tar.gz
cd nginx-1.17.6
./configure \
--user=nginx \
--group=nginx \
--with-http_ssl_module  \
--with-http_stub_status_module
make && make install
yum -y install mariadb  mariadb-server  mariadb-devel
yum -y install   php  php-mysqlnd  php-fpm
