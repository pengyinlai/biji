#!/bin/bash
conf="/etc/keepalived/keepalived.conf"
dev1=`ip route | awk '/192.168.2.5/{print $3}'`
dev2=`ip route | awk '/192.168.2.6/{print $3}'`
sed -ri "/^\s+router_id/c router_id $RANDOM"  $conf
grep -i vrrp_iptables $conf
if [ $? -ne 0 ];then
   sed -i '13i vrrp_iptables' $conf
fi
if [ -n "$dev1" ];then
   sed -i "/interface/s/eth0/$dev1/" $conf
   sed -i '37,$d'  $conf
   sed -i 's/192.168.200.16/192.168.4.80/' $conf
   sed -i '/192.168.200.17/d'    $conf
   sed -i '/192.168.200.18/d'    $conf 
else
   sed -i 's/MASTER/BACKUP/' $conf 
   sed -i "/interface/s/eth0/$dev2/" $conf
   sed -i '37,$d'  $conf
   sed -i 's/192.168.200.16/192.168.4.80/' $conf
   sed -i '/192.168.200.17/d'    $conf
   sed -i '/192.168.200.18/d'    $conf 
fi
